License : Free for personal use 
File Type : ttf 
Visit here to get full version : https://crmrkt.com/Ea6B0Q
Visit here to get all produck: https://creativemarket.com/fajriyandi 
Author : https://www.creativefabrica.com/product/anatomia-script/ref/235499/ 
https://www.dafont.com/fajri-yandi.d7396

Thanks you